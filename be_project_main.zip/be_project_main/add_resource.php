<!DOCTYPE html>
<html lang="en">
<head>
<title>QR-Code Generator</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<style>
*{margin:0px; padding:0px;font-family: Helvetica, Arial, sans-serif;}
h1 { text-align: center; text-shadow: 2px 2px 0px rgba(255,255,255,.7), 5px 7px 0px rgba(0, 0, 0, 0.1);  font-size:50px; margin-top:40px; color:#fff; }
input[type=text]{
    width: 90%;
    padding: 12px 20px;
    margin: 8px 26px;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  font-size:16px;
}
.button1 {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 26px;
    border: none;
    cursor: pointer;
    width: 90%;
  font-size:20px;
}
button:hover {
    opacity: 0.8;
}
.bg {
            background-color: teal;
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
</style>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>
<body >
  <div class="bg">
<h1>Add Resource</h1>
<div class="d-flex justify-content-end">
<h2 class="text-danger text-uppercase text-center"> Auto Resource</h2>
<br>
<br>
</div>

</div>
<div id="form-wrapper" style="width:46%; float:left; border:5px solid rgba(158,158,158,0.6); margin-top:20px; padding:10px">
    <form id="generator" method="post" action="12.php">     
        <label for="codeSize" style="font-size:20px; margin-right:20px;" class="text-danger">Select QR Code Size:</label>
        <select id="codeSize" name="codeSize" style="width:260px; height:40px; " class="text-danger">
            <option value="75">XSmall</option>
            <option value="155">Small</option>
            <option value="186">Medium</option>
            <option value="248" selected="selected">Large</option>
            <option value="300">XLarge</option>
            <option value="450">XXLarge</option>
        </select>
        <br><br>
<label style="font-size:20px; margin-right:20px;"class="text-danger">Enter Resource Id:</label>
        <input type="text" onclick="myFunction()" id="rid" name="resource_id" size="50" placeholder="Enter Resource ID" style="margin-top:20px" autocomplete="off"/ >
<br><br>
<label class="text-danger" style="font-size:20px; margin-right:20px;">Select Resource Type:</label>
<select class="text-danger" id="rtype" name="resourceType" onclick="myFunction()" style="width:260px; height:40px; ">

  <option value="monitor"> Monitor </option>
<option value="cpu"> CPU</option>
<option value="keyboard"> Keyboard</option>
<option value="mouse"> Mouse </option>
<option value="speaker"> Speaker</option>
<option value="projector"> Projector </option>
<option value="e_kit"> Electronic Kit </option>
<option value="bench"> Bench</option>
<option value="chair"> Chair</option>
<option value="cupboard"> Cupboard </option>
<option value="comp_table">Computer Table</option>
<option value="tubelight"> Tubelights </option>
<option value="projector_screens">Projector Screens</option>
<option value="server_box"> Server Box </option>
<option value="podium"> Podium </option>
<option value="Wall_Mount"> Wall Mount</option>
<option value="workstation"> Workstation </option>
</select>
            
<br><br>
<label style="font-size:20px; margin-right:20px;" class="text-danger">Enter Procurement Date:</label>
<input type="date" onclick="myFunction()" id="pdate" name="proc_date" size="30" placeholder="Enter date of Procurement" maxlength=10 style="margin-top:20px" autocomplete="off"/ >

        <br><br>

<label style="font-size:20px; margin-right:20px;"class="text-danger" >Enter Location:</label>
<input type="text" onclick="myFunction()" id="plocation" name="location" size="30" placeholder="Enter a location of product" style="margin-top:20px" autocomplete="off"/ >

        <br><br>

<label style="font-size:20px; margin-right:20px;"class="text-danger">Enter Maintenance Period In Months:</label>
<input type="text" onclick="myFunction()" id="pmaintenance" name="maintenance_period" size="30" placeholder="Enter maintenance period in months " maxlength=2 style="margin-top:20px" autocomplete="off"/ >

        <br><br>
<label style="font-size:20px; margin-right:20px;" class="text-danger">Enter product specifications:</label>
<input type="text" onclick="myFunction()" id="pspecs" name="product_specs" size="300" placeholder="Enter product specifications " style="margin-top:20px" autocomplete="off"/ >

        <br><br>

        <input type="submit" name="submitbtn"  id="submitid" class="button1" value="Submit Data">
        <br>

        <input type="submit" name="generate"  id="generate" class="button1" value="Generate">
    </form>
    <div id="alert" style="height:20px; text-align:center; margin:10px auto"></div>
</div>

  <div style="float:right;">
   <div id="image" style="margin:auto"></div>
   <div id="link" style="margin-top:10px; text-align:center"></div>
  </div>
  
  <div id="code" style="float:left; width:100%; height:20px; text-align:center; margin-top:10px"></div>


<script>
function myFunction() {
     document.getElementById("alert").innerHTML = "";
  }
$("#generate").on("click", function () {
var data = "Resource Id: "+$("#rid").val()+"_Resource Type: "+$("#rtype").val()+" _Procurement Date "+$("#pdate").val()+"_Location: "+$("#plocation").val()+"_Maintenance Period: "+$("#pmaintenance").val()+" Months"+"_Product Specifications: "+$("#pspecs").val();
var size = $("#codeSize").val();

if(data == "") {
    $("#alert").append("<p style='color:cyan;font-size:20px'>Please Enter A Url Or Text</p>"); // If Input Is Blank
    return false;
} else {
    if( $("#image").is(':empty')) {
    
    //QR Code Image
      $("#image").append("<img src='http://chart.apis.google.com/chart?cht=qr&chl=" + data + "&chs=" + size + "' alt='qr' />");

    
    //This Provide An Image Download Link
      $("#link").append("<a style='color:cyan;' href='http://chart.apis.google.com/chart?cht=qr&chl=" + data + "&chs=" + size + "'>Download QR Code</a>");
    
    //This Provide the Image Link Path In Text
      $("#code").append("<p style='color:#cyan;'><strong>Image Link:</strong> http://chart.apis.google.com/chart?cht=qr&chl=" + data + "&chs=" + size + "</p>");
      return false;
} else {
      $("#image").html("");
      $("#link").html("");
      $("#code").html("");
    

      //QR Code Image
      $("#image").append("<img src='http://chart.apis.google.com/chart?cht=qr&chl=" + data + "&chs=" + size + "' alt='qr' />");
    
    //This Provide An Image Download Link
      $("#link").append("<a style='color:cyan;' href='http://chart.apis.google.com/chart?cht=qr&chl=" + data + "&chs=" + size + "' target='_blank'>Download QR Code</a>");
    
    //This Provide the Image Link Path In Text
      $("#code").append("<p style='color:cyan;'><strong>Image Link:</strong> http://chart.apis.google.com/chart?cht=qr&chl=" + data + "&chs=" + size + "</p>");
      return false;
    }
  }
});
</script>




</body>
</html>
