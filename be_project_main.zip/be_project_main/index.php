<html>
<head>
<title> Superadmin </title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>


<style>
*{margin:0px; padding:0px;font-family: Helvetica, Arial, sans-serif;}
h2 { text-align: center; text-shadow: 2px 2px 0px rgba(255,255,255,.7), 5px 7px 0px rgba(0, 0, 0, 0.1);  font-size:50px; margin-top:40px; color:#fff; }
input[type=text]{
    width: 90%;
    padding: 12px 20px;
    margin: 8px 26px;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    font-size:16px;
}
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 26px;
    border: none;
    cursor: pointer;
    width: 25%;
    height:10%;
    font-size:20px;
}

.button1 {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 26px;
    border: none;
    cursor: pointer;
    width: 25%;
    height:10%;
    font-size:20px;
}
button:hover {
    opacity: 0.8;
}

.button1:hover {
    opacity: 0.8;
}

.bg {
            background-color:teal; 
            height: 22%;
            background-position: center;
            background-repeat: repeat;
            background-size: cover;
        }

.jj{
    height: 30%;
    width :80%;
    
}

</style>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>
<body>
    <div class="bg">
 <br>

<h2 color="white"> Super Admin </h2>
<br>
    </div>
   <center>

<div class="container  ">
    <br><br><br>
<div class="card-columns">
    <div class="card w3-aqua ">
     <div class="card-body text-center">

<a href="#"> <h3>  Manage Users </h3> </a>
<br><br><br>
 </div>
  </div>
  <div class="card bg-primary " >
    <div class="card-body text-center">

<a href="add_resource.php"> <h3>  Add Resource </h3> </a>
<br><br><br>
 </div>
  </div>
  <div class="card bg-warning " >
    <div class="card-body text-center">
<h3><a href="scrap_resource.php"> Scrap Resource</a></h3> 
<br><br><br>
</div>
</div>
<div class="card bg-success " >
    <div class="card-body text-center">

 <a href="#"> 
    <h3> Relocate Resource</h3> </a>
    <br><br><br>
</div>
</div>

<div class="card bg-danger ">
    <div class="card-body text-center">
 <a href="/codes/15.html"> <h3> Mark Unavliable</h3> </a>
 <br><br><br>
</div>
</div>

<div class="card w3-grey  " >
    <div class="card-body text-center"> 
        <a href="#"><h3> Maintenance </h3> </a>
        <br><br><br>
    </div>
</div>
<div class="card bg-info ">
    <div class="card-body text-center">
<a href="track_resource.php"><h3> Track Resource</h3> </a>
<br><br><br>
</div>
</div>

<div class="card w3-amber "> 
    <div class="card-body text-center">
    <a href="#">
        <h3> Generate Timetable</h3> </a>
        <br><br><br>
</div>
</div>
<div class="card w3-sand " >
    <div class="card-body text-center">
 <a href="#"><h3> Generate Report</h3> </a>
 <br><br><br>
</div>
</div>

</div>
</div>

   </center>


</body>
</html>

