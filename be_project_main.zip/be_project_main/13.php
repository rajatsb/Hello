<?php

require("conn.php");
$id=$_GET['id'];
$DATE=date("Y-m-d");
$status='TRUE';

//echo $id;
$query = "UPDATE Scrap SET R_Scrap_Action='YES' WHERE R_ID='$id'";

$data=mysqli_query($conn,$query);



	echo"<script type='text/javascript'>alert('ok');</script>";
	
$query2 = "UPDATE Main SET R_Scrap_Status='YES' WHERE R_ID='$id'";
$data2=mysqli_query($conn,$query2);

header("refresh:1; url=scrap_resource.php");
//echo"<script type='text/javascript'>alert('ok');</script>";

?>
