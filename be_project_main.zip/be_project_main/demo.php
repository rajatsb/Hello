<?php

require("conn.php");


$R_ID=$_POST["result"];
$s=(string)R_ID;

$sql = "UPDATE Main m INNER JOIN Scrap s ON m.R_ID=s.R_ID SET m.R_Scrap_Date=s.R_Scrap_Date WHERE m.R_ID =$s ";

$data=mysqli_query($conn,$sql);

if ($conn->query($data)===TRUE) {
echo "Resource Scrapped successfully";
} 
else {
echo "Error in Scrap";
}


//header("refresh:2; url=demo.php");


?>

