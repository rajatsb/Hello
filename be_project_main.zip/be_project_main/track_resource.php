<?php
    include("functions.php");

?>

<!DOCTYPE html>
<html>
<head>
    <title>track_resource</title>
     <!-- Latest compiled and minified CSS -->

 <style type="text/css">
.bg {
            
            height: 22%;
            background-position: center;
            background-repeat: repeat;
            background-size: cover;
        }

 </style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 
</head>

<body>
<div class="w3-teal">
<div class="container">

<h1 class="w3-text-white text-uppercase text-center"> Scrap Resource</h1>
<div class="d-flex justify-content-end">
<h2 class="text-danger text-uppercase text-center"> Auto Resource</h2>
<br>
<br>
</div>

</div>
<br>
  </div>
<div>
  <nav class="navbar navbar-expand-md navbar-dark bg-info">
      <a class="navbar-brand" href="#">Auto-Resource</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown">
            <a class="nav-link" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Notifications 
                <?php
                $query = "SELECT * from `notifications` where `status` = 'unread' order by `date` DESC";
                if(count(fetchAll($query))>0){
                ?>
                <span class="badge badge-light"><?php echo count(fetchAll($query)); ?></span>
              <?php
                }
                    ?>
              </a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
                <?php
                $query = "SELECT * from `notifications` order by `date` DESC";
                 if(count(fetchAll($query))>0){
                     foreach(fetchAll($query) as $i){
                ?>
              <a style ="
                         <?php
                            if($i['status']=='unread'){
                                echo "font-weight:bold;";
                            }
                         ?>
                         " class="dropdown-item" href="view.php?id=<?php echo $i['id'] ?>">
                <small><i><?php echo date('F j, Y, g:i a',strtotime($i['date'])) ?></i></small><br/>
                  <?php 
                  
                if($i['type']=='comment'){
                    echo "Someone not scrapped the resource.";
                }else if($i['type']=='scrap'){
                    echo ucfirst($i['id'])." is sent for scrap.";
                }
                  
                  ?>
                </a>
              <div class="dropdown-divider"></div>
                <?php
                     }
                 }else{
                     echo "No Records yet.";
                 }
                     ?>
            </div>
          </li>
        </ul>
          
      </div>
    </nav>
 
    </div>


 <main role="main" class="container">

<!--
      <div class="starter-template">
        <h1>Bootstrap starter template</h1>
        <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p>
      </div>
-->

<div class="bg-light">
  
 <h1 class="text-warning text-center"> Resource Details </h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> Id </th>
 <th> Resource Type</th>
 <th> Procurement Date </th>
 <th> Location </th>
  <th> Maintenance Period </th>
   <th> Specification </th>
 <th> Scrap Status </th>

 <th> Current Status </th>

 </tr>

 <?php

require('conn.php'); 
 $q = 'SELECT * from Main;';

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['R_ID']; ?> </td>
 <td> <?php echo $res['R_Type']; ?> </td>
 <td> <?php echo $res['Procurement_Date']; ?> </td>
  <td> <?php echo $res['R_Location']; ?> </td>
   <td> <?php echo $res['R_Maintenance_Period']; ?> </td>
    <td> <?php echo $res['R_Specification']; ?> </td>
     <td> <?php echo $res['R_Scrap_Status']; ?> </td>
      <td> <?php echo $res['R_Current_Status']; ?> </td>
 
 

 </tr>

 <?php 
 }
 ?>
 
 </table>  


 

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>
</div>


    </main>


  
<!--

<div class="bg-light">
  
 <h1 class="text-warning text-center"> Display Table Data </h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> Id </th>
 <th> Scrap Date</th>
 <th> Reason </th>
 <th> Yes </th>
 <th> No </th>

 </tr>

 <?php

require('conn.php'); 
 $q = 'SELECT * from Main;';

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['R_ID']; ?> </td>
 <td> <?php echo $res['R_Scrap_Status']; ?> </td>
 <td> <?php echo $res['R_Scrap_Reason']; ?> </td>
 <td> <button class="btn-success btn"> <a href="13.php?id=<?php echo $res['R_ID']; ?>" class="text-white">  Yes </a>  </button> </td>
 <td> <button class="btn-danger btn"> <a href="smsNew.php?id=<?php echo $res['R_ID']; ?>" class="text-white">  No </a>  </button> </td>

 </tr>

 <?php 
 }
 ?>
 
 </table>  


 

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>
</div>
-->


      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</body>

</html>