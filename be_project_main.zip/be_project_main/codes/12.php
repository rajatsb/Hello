<?php
mysql_connect("hostname","usename","password") or die(mysql_error());
$dbase_name="";
mysql_select_db($dbase_name) or die(mysql_error());
$R_ID=$_POST['ID'];
$Resource_Type=$_POST['type'];
$Pro_Date=$_POST['pro-date'];
$Location=$_POST['location'];
$M_Period=$_POST['main-per'];
$Specs=$_Post['specs'];

$query= " INSERT INTO Resource(R_ID,Type,Pro_Date,Location,M_Period,Specification) VALUES('$R_ID','$Resource_Type','$Pro_Date','$Location','$M_Period','$Specs')";

mysql_query($query) or die(mysql_error());
echo "Data Inserted";
//---------------------------------------------------------------------------------------------------------





// QR code generating module to be placed here 





//-----------------------------------------------------------------------------------------------------------



mysql_close();
?>
