<?php
$db_name = "projectdb";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password,$db_name);
error_reporting(0);

if($conn){
	echo "<script type= 'text/javascript'>alert('Connection created successfully');</script>";
} 
else {
echo "<script type= 'text/javascript'>alert('Error in connection');</script>";
}


$R_ID=mysqli_real_escape_string($conn,$_REQUEST['resource_id']);
$R_Type=mysqli_real_escape_string($conn,$_REQUEST['resourceType']);
$Procurement_Date=mysqli_real_escape_string($conn,$_REQUEST['proc_date']);
$R_Location=mysqli_real_escape_string($conn,$_REQUEST['location']);
$R_Maintenance_Period=mysqli_real_escape_string($conn,$_REQUEST['maintenance_period']);
$R_Specification=mysqli_real_escape_string($conn,$_REQUEST['product_specs']);

$sql = "INSERT INTO Main(R_ID,R_Type,Procurement_Date,R_Location,R_Maintenance_Period,R_Specification) VALUES('$R_ID','$R_Type','$Procurement_Date','$R_Location','$R_Maintenance_Period','$R_Specification')";

$data=mysqli_query($conn,$sql);

if ($data) {
echo "<script type= 'text/javascript'>alert('New record created successfully')";
} 
else {
echo "<script type= 'text/javascript'>alert('Error in insertion')";
}

mysqli_close($conn);

//header("refresh:1; url=add_resource.php");
header("location:add_resource.php");
?>
