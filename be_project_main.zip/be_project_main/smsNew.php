<?php

require("conn.php");
$id=$_GET['id'];
$DATE=date("Y-m-d");
$status='TRUE';

//echo $id;
$query = "UPDATE Scrap SET R_Scrap_Action='NO' WHERE R_ID='$id'";

$data=mysqli_query($conn,$query);


echo"<script type='text/javascript'>alert('Error');</script>";
$query2 = "UPDATE Main SET R_Scrap_Status='FALSE' WHERE R_ID='$id'";
$data2=mysqli_query($conn,$query2);
header("location:scrap_resource.php");

//echo"<script type='text/javascript'>alert('ok');</script>";

?>
