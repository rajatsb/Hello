
<!DOCTYPE html>
<html>
 <head>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
  <title>Webslesson Tutorial | Facebook Style Header Notification using PHP Ajax Bootstrap</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  
<div class="w3-blue-grey" >

  <div class="container">


    <h1 class="w3-text-white text-uppercase text-center"> Scrap Resource</h1>
<div class="d-flex justify-content-end">

<br>
<br>
</div>

</div>
<br>
  </div>
<div>

</div>
   <nav class="navbar w3-bisque navbar-inverse">
    <div class="container-fluid">
     <div class="navbar-header">
      <a class="navbar-brand w3-text-white" href="#">Auto-Resource</a>
     </div>

     <ul class="nav navbar-nav navbar-right">
      <li class="dropdown">
       <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-envelope" style="font-size:18px;"></span></a>
       <ul class="dropdown-menu"></ul>
      </li>
     </ul>
    </div>
   </nav>
   <br />
    <main role="main" class="container">

<!--
      <div class="starter-template">
        <h1>Bootstrap starter template</h1>
        <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p>
      </div>
-->

<div class="bg-light">
  
 <h1 class="text-warning text-center"> Display Table Data </h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> Id </th>
 <th> Scrap Date</th>
 <th> Reason </th>
 <th> Yes </th>
 <th> No </th>

 </tr>

 <?php

require('conn.php'); 
 $q = 'SELECT * from Scrap;';

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['R_ID']; ?> </td>
 <td> <?php echo $res['R_Scrap_Date']; ?> </td>
 <td> <?php echo $res['R_Scrap_Reason']; ?> </td>
 <td> <button class="btn-success btn"> <a href="13.php?id=<?php echo $res['R_ID']; ?>" class="text-white">  Yes </a>  </button> </td>
 <td> <button class="btn-danger btn"> <a href="smsNew.php?id=<?php echo $res['R_ID']; ?>" class="text-white">  No </a>  </button> </td>

 </tr>

 <?php 
 }
 ?>
 
 </table>  


 

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>
</div>


    </main>


  
<!--

<div class="bg-light">
  
 <h1 class="text-warning text-center"> Display Table Data </h1>
 <br>
 <table  id="tabledata" class=" table table-striped table-hover table-bordered">
 
 <tr class="bg-dark text-white text-center">
 
 <th> Id </th>
 <th> Scrap Date</th>
 <th> Reason </th>
 <th> Yes </th>
 <th> No </th>

 </tr>

 <?php

require('conn.php'); 
 $q = 'SELECT * from Scrap;';

 $query = mysqli_query($conn,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr class="text-center">
 <td> <?php echo $res['R_ID']; ?> </td>
 <td> <?php echo $res['R_Scrap_Date']; ?> </td>
 <td> <?php echo $res['R_Scrap_Reason']; ?> </td>
 <td> <button class="btn-success btn"> <a href="13.php?id=<?php echo $res['R_ID']; ?>" class="text-white">  Yes </a>  </button> </td>
 <td> <button class="btn-danger btn"> <a href="smsNew.php?id=<?php echo $res['R_ID']; ?>" class="text-white">  No </a>  </button> </td>

 </tr>

 <?php 
 }
 ?>
 
 </table>  


 

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>
</div>
-->


      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 </body>
</html>

<script>
$(document).ready(function(){
 
 function load_unseen_notification(view = '')
 {
  $.ajax({
   url:"view.php",
   method:"POST",
   data:{view:view},
   dataType:"json",
   success:function(data)
   {
    $('.dropdown-menu').html(data.notification);
    if(data.unseen_notification > 0)
    {
     $('.count').html(data.unseen_notification);
    }
   }
  });
 }
 
 load_unseen_notification();
 

 
 
 $(document).on('click', '.dropdown-toggle', function(){
  $('.count').html('');
  load_unseen_notification('yes');
 });
 
 setInterval(function(){ 
  load_unseen_notification();; 
 }, 5000);
 
});
</script>


