<?php

require("conn.php");


$R_ID=$_POST["id"];
$REASON=$_POST["reason"];
$FROM_DATE=$_POST["fromdate"];
$TO_DATE=$_POST["todate"];
//$s=(string)R_ID;

$sql = "INSERT INTO Maintenance VALUES('$R_ID','$REASON','212',needs service','$FROM_DATE','$TO_DATE') ;";
$data=mysqli_query($conn,$sql);

             

             
	echo "Resource with resource id'.$R_ID.'is sent for Servicce Maintenance " ;		
	//	echo '<script type="text/javascript">'; 
//echo 'alert("Resource with resource id'.$R_ID.'is sent for Scrap beacuse the reason is:'.$REASON.'");'; 
//echo 'window.location.href = "scrap_resource.html";';
//echo '</script>';	
	//$sql2="INSERT INTO notifications VALUES('$R_ID', '', 'scrap', 'Scrap Request', 'unread', '$DATE');";
//$data=mysqli_query($conn,$sql2);


 

/*
<script language='JavaScript'>
    window.alert('Succesfully Updated');
    window.location.href='scrap_resource.php';
   </script>
-->
*/

$sql2="INSERT INTO notifications VALUES('$R_ID', 'service', 'Service Request', 'unread', '$DATE');";
$data=mysqli_query($conn,$sql2);

//header("refresh:2; url=demo.php");

?>